## 6.100A PSet 1: Part C
## Name:
## Time Spent:
## Collaborators:

##############################################
## Get user input for initial_deposit below ##
##############################################

down_payment = 800000 * .25

initial_deposit = float(input("your count's initial deposit is:"))


#########################################################################
## Initialize other variables you need (if any) for your program below ##
#########################################################################
months = 36
steps = 0
top_rate = 1.0
low_rate = 0
amount_saved = 0
differece = 100

##################################################################################################
## Determine the lowest rate of return needed to get the down payment for your dream home below ##
##################################################################################################
if initial_deposit == 0:
    print("fuck away!")
while 1:
    steps += 1
    mid_rate = float((top_rate + low_rate) / 2)
    amount_saved = initial_deposit * ((1 + mid_rate/12) ** months)
   
    if amount_saved > down_payment  :
        top_rate = mid_rate
       
   
    elif amount_saved < down_payment :
        low_rate  = mid_rate

    if top_rate - low_rate < 1e-4:

        break
        print("impossible")
    
   
print(steps)
print(mid_rate)